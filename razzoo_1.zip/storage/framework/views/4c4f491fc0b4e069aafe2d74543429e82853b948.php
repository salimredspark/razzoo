<footer class="app-footer">
    <div class="site-footer-right">        
        <?php $version = Voyager::getVersion(); ?>
        <?php if(!empty($version)): ?>
           Razzoo Admin - <?php echo e($version); ?>

        <?php endif; ?>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\projects\razzoo\vendor\tcg\voyager\src/../resources/views/partials/app-footer.blade.php ENDPATH**/ ?>