<?php $__env->startSection('content'); ?>
<div class="page-content">
    <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('voyager::dimmers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="analytics-container">
        <div id="embed-api-auth-container">

            <!--dashboard html-->
            <div id="resources" class="tab-pane fade in active">
                <h3><i class="voyager-dashboard"></i> Dashboard <small>Your go to place for Business Loans.</small></h3>

                <div class="collapsible">
                    <div class="collapse-head collapsed" data-toggle="collapse" data-target="#links" aria-expanded="false" aria-controls="links">
                        <h4>Menu</h4>
                        <i class="voyager-angle-down" style="display: inline;"></i>
                        <i class="voyager-angle-up" style="display: block;"></i>
                    </div>
                    <div class="collapse-content collapse" id="links" aria-expanded="true">
                        <div class="row">
                            <div class="col-md-4">
                                <a href="<?php echo e(route('voyager.loan.index')); ?>" class="voyager-link" style="background-image:url('<?php echo e(voyager_asset('images/compass/documentation.jpg')); ?>')">
                                    <span class="resource_label"><i class="voyager-documentation"></i> <span class="copy">Loan Application (<?php echo e($totalApplication); ?>)</span></span>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="<?php echo e(route('voyager.users.index')); ?>" class="voyager-link" style="background-image:url('<?php echo e(voyager_asset('images/compass/voyager-home.jpg')); ?>')">
                                    <span class="resource_label"><i class="voyager-browser"></i> <span class="copy">Users</span></span>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="<?php echo e(route('voyager.media.index')); ?>" class="voyager-link" style="background-image:url('<?php echo e(voyager_asset('images/compass/hooks.jpg')); ?>')">
                                    <span class="resource_label"><i class="voyager-hook"></i> <span class="copy">Media</span></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\razzoo\vendor\tcg\voyager\src/../resources/views/index.blade.php ENDPATH**/ ?>