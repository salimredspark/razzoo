<?php $__env->startSection('content'); ?>
<section class="content-section py-5">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="wizard-steps text-center">
                    <span class="tick"><img src="<?php echo e(url('images/icon-tick.png')); ?>" class="img-fluid" alt=""></span>
                    <h3 class="text-success">Congratulations! <br> your loan is pre-approved for value of $84,000 at 8.65% p.a. with no upfront or ongoing fees.</h3>
                    <h4 class="mb-5">Your loan will be disembursed within 48 hours on sucessfull background verification.
                    </h4>
                    <h5 class="text-primary">Your application id is : <?php echo e($application_id); ?>.</h5>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\razzoo\resources\views/loan/thankyou.blade.php ENDPATH**/ ?>