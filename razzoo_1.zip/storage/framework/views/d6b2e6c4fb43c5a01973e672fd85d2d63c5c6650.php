<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon.png')); ?>" sizes="11x11">
    <title>Razzoo - Instant Business Loans</title>

    <!--
=====================================================================
	CSS
=====================================================================
-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/responsive.css')); ?>">
    <!--
=====================================================================
	JS
=====================================================================
-->
    <script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
    <!-- Modernizr -->
    <!--[if lt IE 9]>
 <script src="<?php echo e(asset('js/html5shiv.js')); ?>"></script>
 <script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>
<![endif]-->
    <!--[if !IE]><!-->
    <script>
        if ( /*@cc_on!@*/ false) {
            document.documentElement.className += ' ie10';
        }
    </script>
    <!--<![endif]-->

</head>

<body>    
    <div class="main-wrapper">
        <header id="header">
            <nav class="navbar navbar-expand-sm navbar-light">
                <div class="container">
                    <!-- Brand -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(url('images/logo.png')); ?>" alt="<?php echo e(config('app.name', 'Razzoo')); ?>" class="img-fluid">
                    </a>
                    <div class="header-right ml-auto">
                        <div class="callus">
                            <span class="call-icon"><img src="<?php echo e(url('images/phone-icon.png')); ?>" class="img-fluid" alt=""></span>
                            1300 000 000
                        </div>
                        <a href="<?php echo e(url('/loan-started')); ?>" class="btn btn-lg btn-primary">Get Started</a>
                    </div>
                </div>
            </nav>
        </header>

        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

        </div>
        <?php elseif(Session::has('error')): ?>
        <div class="alert alert-error">
            <?php echo e(Session::get('error')); ?>

        </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
        
    </div>
    
    <?php echo $__env->make('cookieConsent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <footer>
        &copy;<?php echo e(date("Y")); ?>, Razzoo. All Rights Reserved.
    </footer>
    
    <script src="<?php echo e(asset('js/jquery-1.11.3.min.js')); ?>"></script>
    <script language="javascript" src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script language="javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    
</body>

</html><?php /**PATH C:\xampp\htdocs\projects\razzoo\resources\views/layouts/app.blade.php ENDPATH**/ ?>