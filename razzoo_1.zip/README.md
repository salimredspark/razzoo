<p align="center"><img src="http://redspark.biz/Designers/razzoo/images/logo.png" width="185"></p>

<p align="center">

</p>

## About Razzoo

Your go to place for Business Loans

## Site Ref: https://www.razzoo.com

## Vasudev Website Requirements

 - PHP Version 7.2.10 | Ref: https://www.php.net
 - Laravel Version 5.8.35 | Ref: https://laravel.com/docs/5.8 
 